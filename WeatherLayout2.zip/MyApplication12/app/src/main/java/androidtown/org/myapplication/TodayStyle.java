package androidtown.org.myapplication;

import android.graphics.Color;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.Spinner;
import android.widget.TextView;

import android.support.v7.app.AppCompatActivity;

public class TodayStyle extends AppCompatActivity {
    Spinner spi_gender,spi_style;
    ListView list;
    ArrayAdapter adapter,adapter2;

    String select_gender,select_style;
    String[] genderData ={"성별","남","여"};
    String[] styleData ={"스타일","베이직","러블리","섹시","유니크","스트릿"};

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_style);

            spi_gender = (Spinner) findViewById(R.id.gender);
            spi_style = (Spinner) findViewById(R.id.style);
            list = (ListView) findViewById(R.id.list);

            adapter = new ArrayAdapter(this, android.R.layout.simple_spinner_item, genderData);
            spi_gender.setAdapter(adapter);
            spi_gender.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
                @Override
                public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                    ((TextView) parent.getChildAt(0)).setTextColor(Color.WHITE);
                    select_gender = genderData[position];
                }

                @Override
                public void onNothingSelected(AdapterView<?> parent) {
                }
            });

            adapter2 = new ArrayAdapter(this, android.R.layout.simple_spinner_item, styleData);
            spi_style.setAdapter(adapter2);
            spi_style.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
                @Override
                public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                    ((TextView) parent.getChildAt(0)).setTextColor(Color.WHITE);
                    select_style = styleData[position];
                }

                @Override
                public void onNothingSelected(AdapterView<?> parent) {
                }
            });

            list.setVisibility(View.INVISIBLE);
        }
}
