package androidtown.org.myapplication;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;

public class Closet extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_closet);
    }
}
