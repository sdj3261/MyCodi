package org.androidtown.myapplication;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;

import android.Manifest;
import android.content.Context;
import android.content.pm.PackageManager;
import android.graphics.Typeface;
import android.location.Address;
import android.location.Criteria;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.os.Build;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.TextView;
import android.widget.Toast;


import java.util.List;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;
import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;

public class MainActivity extends AppCompatActivity {
    private LocationManager locationManager;
    private LocationListener locationListener;
    Retrofit retrofit;
    WeatherService apiService;

    private final static String ServiceKey = "40d451df686b06ada274283693d620af";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        TextView temp4 = findViewById(R.id.temp4);
        TextView temp5 = findViewById(R.id.temp5);

        retrofit = new Retrofit.Builder().baseUrl("http://api.openweathermap.org").addConverterFactory(GsonConverterFactory.create()).build();
        apiService = retrofit.create(WeatherService.class);
        settingGPS();
        Location userLocation = getMyLocation();
        String lat = "37.5683";
        String lon = "126.9778";
        if (userLocation != null) {
            lat = Double.toString(userLocation.getLatitude());
            lon = Double.toString(userLocation.getLongitude());
            temp4.setText(lat);
            temp5.setText(lon);
        }
        Call<WeatherTest> call = apiService.getCurrentWeatherData(lat, lon, "metric", ServiceKey);
        call.enqueue(new Callback<WeatherTest>() {
            @Override
            public void onResponse(Call<WeatherTest> call, Response<WeatherTest> response) {
                TextView temp = findViewById(R.id.temp);
                TextView temp2 = findViewById(R.id.temp2);
                TextView temp3 = findViewById(R.id.temp3);
                TextView temp6 = findViewById(R.id.temp6);
                TextView temp7 = findViewById(R.id.temp7);
                TextView temp8 = findViewById(R.id.temp8);

                Log.v("Test", "on Response");
                WeatherTest weatherResponse = response.body();
                assert weatherResponse != null;


                String stringBuilder = "Country: " +
                        weatherResponse.getSys().getCountry() +
                        "\n" +
                        "Temperature: " +
                        weatherResponse.getMain().getTemp() +
                        "\n" +
                        "Temperature(Min): " +
                        weatherResponse.getMain().getTempMin() +
                        "\n" +
                        "Temperature(Max): " +
                        weatherResponse.getMain().getTempMax() +
                        "\n" +
                        "Humidity: " +
                        weatherResponse.getMain().getHumidity() +
                        "\n" +
                        "Pressure: " +
                        weatherResponse.getMain().getPressure();

                String des = weatherResponse.getWeather().get(0).getDescription().toString();

                temp.setText("현재 온도는 " + weatherResponse.getMain().getTemp().toString().trim() + "입니다.");
                temp2.setText(weatherResponse.getWeather().get(0).getMain().toString());

                if (containsIgnoreCase(des, "rain")) {
                    temp3.setText("우산챙겨");
                } else
                    temp3.setText("우산필요없어");
                temp6.setText("도시이름 : " + weatherResponse.getName());
                temp7.setText("습도 : " + weatherResponse.getMain().getHumidity());
                temp8.setText("현재 날씨 설명 : " + des);
            }

            public boolean containsIgnoreCase(String str, String searchStr) {
                if (str == null || searchStr == null) return false;

                final int length = searchStr.length();
                if (length == 0)
                    return true;

                for (int i = str.length() - length; i >= 0; i--) {
                    if (str.regionMatches(true, i, searchStr, 0, length))
                        return true;
                }
                return false;
            }


            @Override
            public void onFailure(Call<WeatherTest> call, Throwable t) {
                Log.v("Test", "onFailure");
            }
        });

    }

    private void settingGPS() {
        // Acquire a reference to the system Location Manager
        locationManager = (LocationManager) this.getSystemService(Context.LOCATION_SERVICE);

        locationListener = new LocationListener() {
            public void onLocationChanged(Location location) {
                double latitude = location.getLatitude();
                double longitude = location.getLongitude();
                // TODO 위도, 경도로 하고 싶은 것
            }

            public void onStatusChanged(String provider, int status, Bundle extras) {
            }

            public void onProviderEnabled(String provider) {
            }

            public void onProviderDisabled(String provider) {
            }
        };
    }

    private Location getMyLocation() {
        Location currentLocation = null;
        // Register the listener with the Location Manager to receive location updates
        if (ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED && ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            // 사용자 권한 요청
            ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.ACCESS_FINE_LOCATION}, 100);
        } else {
            locationManager.requestLocationUpdates(LocationManager.NETWORK_PROVIDER, 0, 0, locationListener);
            locationManager.requestLocationUpdates(LocationManager.GPS_PROVIDER, 0, 0, locationListener);
            Log.d("gpa", "previous location");
            // 수동으로 위치 구하기
            String locationProvider = LocationManager.GPS_PROVIDER;
            List<String> providers = locationManager.getProviders(true);
            Location bestLocation = null;
            for (String provider : providers) {
                Location l = locationManager.getLastKnownLocation(provider);
                if (l == null) {
                    continue;
                }
                if (bestLocation == null || l.getAccuracy() < bestLocation.getAccuracy()) {
                    // Found best last known location: %s", l);
                    bestLocation = l;
                }
            }
            return bestLocation;
        }
        return null;
    }

    boolean canReadLocation = false;

    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        if (requestCode == 100) {
            if (grantResults.length == 1 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
// success!
                Location userLocation = getMyLocation();
                if (userLocation != null) {
// todo 사용자의 현재 위치 구하기
                    double latitude = userLocation.getLatitude();
                    double longitude = userLocation.getLongitude();
                }
                canReadLocation = true;
            } else {
// Permission was denied or request was cancelled
                canReadLocation = false;
            }
        }
    }

    @Override
    protected void onStart() {
        super.onStart();
        if (ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED && ActivityCompat.checkSelfPermission(MainActivity.this, Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            if (ActivityCompat.shouldShowRequestPermissionRationale(this, android.Manifest.permission.ACCESS_FINE_LOCATION) &&
                    ActivityCompat.shouldShowRequestPermissionRationale(this, Manifest.permission.ACCESS_COARSE_LOCATION)) {
                ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.ACCESS_COARSE_LOCATION}, 100);
                return;
            } else {
                ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.ACCESS_COARSE_LOCATION}, 100);
                return;
            }
        }
    }
}