package androidtown.org.myapplication;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;

public class Closet extends AppCompatActivity {
    Button search, cam;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_closet);
        search=(Button)findViewById(R.id.search);
        cam=(Button)findViewById(R.id.cam);
    }
    public void click(View v){
        Intent CAM = new Intent(getApplicationContext(),Cam.class);
        Intent SEARCH = new Intent(getApplicationContext(),Search.class);
        switch (v.getId()){
            case R.id.cam:
                startActivity(CAM);
                break;
            case R.id.search:
                startActivity(SEARCH);
                break;
        }

    }
}
