package androidtown.org.myapplication;

import android.graphics.drawable.Drawable;
import android.support.v7.app.AppCompatActivity;
import android.app.SearchManager;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.SearchView;
import android.widget.TextView;
import android.widget.Toast;

import org.w3c.dom.Text;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOError;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.math.MathContext;
import java.security.PublicKey;

public class Search extends AppCompatActivity {

    Button closet1,closet2;
    public static String str;
    TextView view;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_search);
        view = (TextView)findViewById(R.id.view);


    }
//    옷 개수마다 switch 개설
    public void click(View v){
        StringBuffer data = new StringBuffer();
        FileInputStream fis;
        BufferedReader buffer;
        String str;
        switch (v.getId()){
            case R.id.closet1:
                try {
                    fis= openFileInput("file.txt");
                    buffer = new BufferedReader
                            (new InputStreamReader(fis));
                   str = buffer.readLine();
                    while (str != null) {
                        data.append(str + "\n");
                        str = buffer.readLine();
                    }
                    view.setText(data);
                    buffer.close();
                } catch (Exception e) {
                    e.printStackTrace();
                }
                break;
            case R.id.closet2:
                try {
                    fis= openFileInput("file2.txt");
                    buffer = new BufferedReader
                            (new InputStreamReader(fis));
                    str = buffer.readLine();
                    while (str != null) {
                        data.append(str + "\n");
                        str = buffer.readLine();
                    }
                    view.setText(data);
                    buffer.close();
                } catch (Exception e) {
                    e.printStackTrace();
                }
                break;
        }

    }






}
