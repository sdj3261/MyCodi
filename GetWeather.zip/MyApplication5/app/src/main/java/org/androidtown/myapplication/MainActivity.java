package org.androidtown.myapplication;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.graphics.Typeface;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.TextView;


import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;
import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;

public class MainActivity extends AppCompatActivity {
    Retrofit retrofit;
    WeatherService apiService;
    private final static String ServiceKey = "40d451df686b06ada274283693d620af";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        retrofit = new Retrofit.Builder().baseUrl("http://api.openweathermap.org").addConverterFactory(GsonConverterFactory.create()).build();
        apiService = retrofit.create(WeatherService.class);

        Call<WeatherTest> call = apiService.getCurrentWeatherData("36.695481","126.832609","metric",ServiceKey);
        call.enqueue(new Callback<WeatherTest>() {
            @Override
            public void onResponse(Call<WeatherTest> call, Response<WeatherTest> response) {
                TextView temp = findViewById(R.id.temp);
                Log.v("Test", "on Response");
                WeatherTest weatherResponse = response.body();
                assert weatherResponse != null;

                String stringBuilder = "Country: " +
                        weatherResponse.getSys().getCountry() +
                        "\n" +
                        "Temperature: " +
                        weatherResponse.getMain().getTemp() +
                        "\n" +
                        "Temperature(Min): " +
                        weatherResponse.getMain().getTempMin() +
                        "\n" +
                        "Temperature(Max): " +
                        weatherResponse.getMain().getTempMax() +
                        "\n" +
                        "Humidity: " +
                        weatherResponse.getMain().getHumidity() +
                        "\n" +
                        "Pressure: " +
                        weatherResponse.getMain().getPressure();

                System.out.println(weatherResponse.getMain().getTemp());
                temp.setText("현재 온도는 " + weatherResponse.getMain().getTemp().toString().trim() + "입니다.");
            }

            @Override
            public void onFailure(Call<WeatherTest> call, Throwable t) {
                Log.v("Test", "onFailure");
            }
        });

    }
}
